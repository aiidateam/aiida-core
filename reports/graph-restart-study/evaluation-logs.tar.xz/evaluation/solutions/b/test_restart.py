"""Local checks using an isolated, brokerless profile."""
import pytest

from restart_solution import run_restart

pytest_plugins = ['aiida.tools.pytest_fixtures']


@pytest.mark.parametrize('fail_until,fatal,count,success', [(2, False, 3, True), (10, False, 5, False), (2, True, 1, False)])
def test_restart(aiida_profile, fail_until, fatal, count, success):
    node = run_restart(fail_until, fatal)
    children = [child for child in node.called_descendants if child.process_label == 'FlakyChild']
    assert len(children) == count
    assert node.is_finished_ok == success
    if success:
        assert node.outputs.result.value == 30
        successful = next(child for child in children if child.is_finished_ok)
        assert node.outputs.result.pk == successful.outputs.result.pk
    else:
        assert node.is_failed
