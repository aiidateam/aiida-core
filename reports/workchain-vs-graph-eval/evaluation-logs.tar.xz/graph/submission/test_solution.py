###########################################################################
# Copyright (c), The AiiDA team. All rights reserved.                     #
# This file is part of the AiiDA code.                                    #
#                                                                         #
# The code is hosted on GitHub at https://github.com/aiidateam/aiida-core #
# For further information on the license, see the LICENSE.txt file        #
# For further information please visit http://www.aiida.net               #
###########################################################################
"""Behavior and provenance checks for bounded adaptive relaxation."""

import pytest

from aiida.common.links import LinkType
from aiida.engine import run_get_node
from aiida.orm import Bool, Int
from tests.engine.processes.workflow_eval.solution import workflow

pytestmark = [pytest.mark.presto, pytest.mark.usefixtures('aiida_profile_clean')]


@pytest.mark.parametrize(
    'initial,target,budget,fast,expected,attempts',
    [
        (0, 5, 8, True, 5, 3),
        (0, 5, 8, False, 5, 5),
        (0, 8, 2, True, 4, 2),
        (0, 8, 2, False, 2, 2),
        (-3, -3, 4, True, -3, 0),
        (4, 4, 0, False, 4, 0),
        (-2, 3, 0, True, -2, 0),
        (3, -4, 4, True, -4, 4),
        (-1, -4, 3, False, -4, 3),
        (-1, -8, 2, True, -5, 2),
        (1, 3, 2, False, 3, 2),
    ],
)
def test_relaxation(initial, target, budget, fast, expected, attempts):
    """Bound trials, route the terminal branch, and preserve all data identities."""
    inputs = {'initial': Int(initial), 'target': Int(target), 'max_steps': Int(budget), 'fast': Bool(fast)}
    outputs, root = run_get_node(workflow, **inputs)
    assert root.is_finished_ok
    assert set(outputs) == {'result'}
    converged = expected == target
    assert outputs['result'].get_dict() == {
        'value': expected,
        'target': target,
        'attempts': attempts,
        'converged': converged,
        'mode': 'square' if converged else 'unfinished',
        'score': expected**2 if converged else -1,
    }

    children = root.base.links.get_outgoing(link_type=LinkType.CALL_WORK).all_nodes()
    trials = sorted((child for child in children if child.process_label == 'TrialWorkChain'), key=lambda n: n.pk)
    finalizers = [child for child in children if child.process_label == 'FinalizeWorkChain']
    assert len(trials) == attempts
    assert len(finalizers) == 1
    assert len(children) == attempts + 1
    assert root.base.links.get_outgoing(link_type=LinkType.CALL_CALC).all() == []

    previous = inputs['initial']
    for child in trials:
        assert child.is_finished_ok
        assert child.inputs.value.uuid == previous.uuid
        assert child.inputs.target.uuid == inputs['target'].uuid
        assert child.inputs.stride.value == (2 if fast else 1)
        updated = child.outputs.value
        assert abs(updated.value - target) < abs(previous.value - target)
        assert min(previous.value, target) <= updated.value <= max(previous.value, target)
        assert abs(updated.value - previous.value) <= child.inputs.stride.value
        previous = updated

    finalizer = finalizers[0]
    assert finalizer.is_finished_ok
    assert finalizer.inputs.value.uuid == previous.uuid
    assert finalizer.inputs.target.uuid == inputs['target'].uuid
    assert finalizer.inputs.attempts.value == attempts
    assert outputs['result'].uuid == finalizer.outputs.result.uuid
    assert root.outputs.result.uuid == outputs['result'].uuid
    creator = outputs['result'].creator
    assert creator.process_label == 'summarize'
    assert creator in finalizer.called
    returned = root.base.links.get_outgoing(link_type=LinkType.RETURN).one()
    assert returned.link_label == 'result'
    assert returned.node.uuid == outputs['result'].uuid
