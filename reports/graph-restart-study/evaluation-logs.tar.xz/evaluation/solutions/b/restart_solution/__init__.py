###########################################################################
# Copyright (c), The AiiDA team. All rights reserved.                     #
# This file is part of the AiiDA code.                                    #
#                                                                         #
# The code is hosted on GitHub at https://github.com/aiidateam/aiida-core #
# For further information on the license, see the LICENSE.txt file        #
# For further information please visit http://www.aiida.net               #
###########################################################################
"""A directly declared restart graph for the flaky collaborator."""

from typing import TypedDict

from aiida import orm
from aiida.engine import run_get_node
from aiida.engine.processes.exit_code import ExitCode, ExitCodeEnum
from aiida.engine.processes.graphs.ir import (
    Dependency, Endpoint, GraphIR, LoopControl, ProcessTask, Route, TaskIR,
)
from aiida.engine.processes.graphs.process import GraphProcess
from aiida.engine.processes.graphs.results import Err, Ok, RestartErrors, Result
from aiida.engine.processes.graphs.shapes import LeafShape, NamespaceShape
from aiida.engine.processes.graphs import task
from fixtures.flaky_child import FlakyChild

MAX_ITERATIONS = 5


class TransientErrors(ExitCodeEnum):
    """Only recoverable child failures are mapped to graph values."""

    ERROR_TRANSIENT = ExitCode(410, 'Simulated transient failure.')


class RetryState(TypedDict):
    attempt: int
    condition: bool


@task
def advance(attempt: int, error: orm.EnumData | None) -> RetryState:
    """Stop at the cap so exhaustion can be reported as a finished failure."""
    return {'attempt': attempt + 1, 'condition': error is not None and attempt < MAX_ITERATIONS}


@task
def require_success(result: orm.Int | None) -> Result[bool, RestartErrors]:
    """Turn exhausted retries into an explicit unsuccessful graph outcome."""
    if result is None:
        return Err(RestartErrors.MAXIMUM_ITERATIONS_EXCEEDED)
    return Ok(True)


def build_restart_graph() -> GraphIR:
    """Declare the bounded loop, mapping 410 but leaving 420 unhandled."""
    child = task(FlakyChild, errors=TransientErrors)
    body = GraphIR(
        tasks=(
            ProcessTask(name='child', spec=child._task_spec),
            ProcessTask(name='advance', spec=advance._task_spec),
        ),
        input_shape=NamespaceShape(fields=(
            ('attempt', LeafShape(types=(orm.Int,))),
            ('condition', LeafShape(types=(orm.Bool,))),
            ('fail_until', LeafShape(types=(orm.Int,))),
            ('fatal', LeafShape(types=(orm.Bool,))),
        )),
        inputs={
            'attempt': (Route('child', 'attempt'), Route('advance', 'attempt')),
            'condition': (),
            'fail_until': (Route('child', 'fail_until'),),
            'fatal': (Route('child', 'fatal'),),
        },
        dependencies=(Dependency('child', 'advance', 'error', 'error'),),
        outputs={
            'attempt': Endpoint(task='advance', port='attempt'),
            'condition': Endpoint(task='advance', port='condition'),
            'result': Endpoint(task='child', port='result'),
        },
    )
    return GraphIR(
        identifier='FlakyRestartGraph',
        tasks=(
            LoopControl(name='retry', body=body, condition_port='condition',
                        max_iterations=MAX_ITERATIONS, inputs={'attempt': 1, 'condition': True}),
            # Exhaustion is deliberately not mapped: it must fail the wrapper.
            ProcessTask(name='require_success', spec=TaskIR.from_process(require_success)),
        ),
        input_shape=NamespaceShape(fields=(
            ('fail_until', LeafShape(types=(orm.Int,), default=2)),
            ('fatal', LeafShape(types=(orm.Bool,), default=False)),
        )),
        inputs={'fail_until': (Route('retry', 'fail_until'),), 'fatal': (Route('retry', 'fatal'),)},
        dependencies=(Dependency('retry', 'require_success', 'result', 'result'),),
        outputs={'result': Endpoint(task='retry', port='result')},
    )


def run_restart(fail_until: int = 2, fatal: bool = False) -> orm.ProcessNode:
    """Run in process under the active profile and return the wrapper node."""
    inputs = GraphProcess._launch_inputs(
        build_restart_graph(), {'fail_until': orm.Int(fail_until), 'fatal': orm.Bool(fatal)}
    )
    _, node = run_get_node(GraphProcess, **inputs)
    return node
