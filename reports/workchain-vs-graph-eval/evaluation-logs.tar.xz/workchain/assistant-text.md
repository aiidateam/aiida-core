I’ll implement the loop and mode selection in the root WorkChain, then add tests for trial bounds, state transitions, and output provenance.


Implemented `solution.py` with a bounded conventional WorkChain, root-level branching, sequential child execution, and unchanged result-node forwarding.

Added `test_solution.py` covering convergence, exhaustion, zero trials, negative/descending states, both speeds, and provenance.

Test command:
```bash
uv run --no-sync pytest --broker-backend=none -q tests/engine/processes/workflow_eval
```
**23 passed**, 1 event-loop deprecation warning.

No implementation blockers. Ruff checks unavailable because Ruff is not installed.