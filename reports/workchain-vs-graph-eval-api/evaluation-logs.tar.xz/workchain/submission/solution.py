###########################################################################
# Copyright (c), The AiiDA team. All rights reserved.                     #
# This file is part of the AiiDA code.                                    #
#                                                                         #
# The code is hosted on GitHub at https://github.com/aiidateam/aiida-core #
# For further information on the license, see the LICENSE.txt file        #
# For further information please visit http://www.aiida.net               #
###########################################################################
"""Bounded adaptive relaxation using provenance-preserving child workflows."""

from aiida.engine import ToContext, WorkChain, if_, while_
from aiida.engine.processes.workchains.workchain import WorkChainSpec
from aiida.orm import Bool, Dict, Int, Str

from .collaborators import FinalizeWorkChain, TrialWorkChain


class RelaxationWorkChain(WorkChain):
    """Advance towards a target within a trial budget, then summarize the outcome."""

    @classmethod
    def define(cls, spec: WorkChainSpec) -> None:
        super().define(spec)
        for name in ('initial', 'target', 'max_steps'):
            spec.input(name, valid_type=Int)
        spec.input('fast', valid_type=Bool)
        spec.output('result', valid_type=Dict)
        spec.outline(
            cls.setup,
            while_(cls.should_run_trial)(cls.run_trial, cls.inspect_trial),
            if_(cls.is_converged)(cls.select_success).else_(cls.select_unfinished),
            cls.finalize,
            cls.results,
        )

    def setup(self) -> None:
        """Initialize orchestration state and select the stride."""
        self.ctx.value = self.inputs.initial
        self.ctx.attempts = 0
        self.ctx.stride = Int(2 if self.inputs.fast.value else 1)

    def is_converged(self) -> bool:
        """Return whether the current state has reached the target."""
        return self.ctx.value.value == self.inputs.target.value

    def should_run_trial(self) -> bool:
        """Stop at convergence or exhaustion, including a zero trial budget."""
        return not self.is_converged() and self.ctx.attempts < self.inputs.max_steps.value

    def run_trial(self) -> ToContext:
        """Submit exactly one scientific update and wait for its output."""
        return ToContext(trial=self.submit(
            TrialWorkChain,
            value=self.ctx.value,
            target=self.inputs.target,
            stride=self.ctx.stride,
        ))

    def inspect_trial(self) -> None:
        """Carry forward the child's existing output and count the completed trial."""
        self.ctx.value = self.ctx.trial.outputs.value
        self.ctx.attempts += 1

    def select_success(self) -> None:
        """Select converged postprocessing in the root workflow."""
        self.ctx.mode = Str('square')

    def select_unfinished(self) -> None:
        """Select normal budget-exhaustion postprocessing."""
        self.ctx.mode = Str('unfinished')

    def finalize(self) -> ToContext:
        """Delegate report creation to the finalization workflow."""
        return ToContext(finalizer=self.submit(
            FinalizeWorkChain,
            value=self.ctx.value,
            target=self.inputs.target,
            attempts=Int(self.ctx.attempts),
            mode=self.ctx.mode,
        ))

    def results(self) -> None:
        """Return the existing report without creating or copying data."""
        self.out('result', self.ctx.finalizer.outputs.result)


workflow = RelaxationWorkChain
