###########################################################################
# Copyright (c), The AiiDA team. All rights reserved.                     #
# This file is part of the AiiDA code.                                    #
#                                                                         #
# The code is hosted on GitHub at https://github.com/aiidateam/aiida-core #
# For further information on the license, see the LICENSE.txt file        #
# For further information please visit http://www.aiida.net               #
###########################################################################
"""Bounded adaptive relaxation using graph orchestration and scientific children."""

from aiida.engine import graph, task

from .collaborators import FinalizeWorkChain, TrialWorkChain

trial = task(TrialWorkChain)
finalize = task(FinalizeWorkChain)


@graph
def workflow(initial: int, target: int, max_steps: int, fast: bool) -> dict:
    """Advance towards the target within the budget, then return the child's report."""
    if fast:
        stride = 2
    else:
        stride = 1
    value = initial
    attempts = 0
    while value != target and attempts < max_steps:
        step = trial(value=value, target=target, stride=stride)
        value = step.value
        attempts = attempts + 1
    if value == target:
        mode = 'square'
    else:
        mode = 'unfinished'
    report = finalize(value=value, target=target, attempts=attempts, mode=mode)
    return report.result
