###########################################################################
# Copyright (c), The AiiDA team. All rights reserved.                     #
# This file is part of the AiiDA code.                                    #
#                                                                         #
# The code is hosted on GitHub at https://github.com/aiidateam/aiida-core #
# For further information on the license, see the LICENSE.txt file        #
# For further information please visit http://www.aiida.net               #
###########################################################################
"""Focused boundary and provenance tests for bounded relaxation."""

import pytest

from aiida.common.links import LinkType
from aiida.engine import run_get_node
from aiida.orm import Bool, Int

from .collaborators import FinalizeWorkChain, TrialWorkChain
from .solution import workflow

pytestmark = [pytest.mark.presto, pytest.mark.usefixtures('aiida_profile_clean')]


@pytest.mark.parametrize(
    'initial,target,budget,fast,states,mode',
    [
        pytest.param(0, 3, 5, False, [1, 2, 3], 'square', id='slow-convergence'),
        pytest.param(0, 3, 5, True, [2, 3], 'square', id='fast-no-overshoot'),
        pytest.param(0, 5, 2, False, [1, 2], 'unfinished', id='slow-exhaustion'),
        pytest.param(0, 5, 2, True, [2, 4], 'unfinished', id='fast-exhaustion'),
        pytest.param(-3, -3, 0, False, [], 'square', id='already-converged-zero-budget'),
        pytest.param(-3, -3, 5, True, [], 'square', id='already-converged-spare-budget'),
        pytest.param(2, -4, 0, True, [], 'unfinished', id='no-trial-budget'),
        pytest.param(1, -4, 3, True, [-1, -3, -4], 'square', id='descending-fast'),
        pytest.param(-2, -4, 2, False, [-3, -4], 'square', id='descending-slow'),
    ],
)
def test_relaxation(initial, target, budget, fast, states, mode):
    """Check exact trial states and that all scientific outputs retain their creators."""
    outputs, root = run_get_node(
        workflow, initial=Int(initial), target=Int(target), max_steps=Int(budget), fast=Bool(fast)
    )
    assert root.is_finished_ok
    value = states[-1] if states else initial
    assert outputs['result'].get_dict() == {
        'value': value,
        'target': target,
        'attempts': len(states),
        'converged': mode == 'square',
        'mode': mode,
        'score': value**2 if mode == 'square' else -1,
    }

    calls = root.base.links.get_outgoing(link_type=LinkType.CALL_WORK).all_nodes()
    trials = sorted((child for child in calls if child.process_class is TrialWorkChain), key=lambda node: node.pk)
    finalizers = [child for child in calls if child.process_class is FinalizeWorkChain]
    assert len(calls) == len(states) + 1
    assert len(trials) == len(states)
    assert len(finalizers) == 1
    previous = root.inputs.initial
    for trial, expected in zip(trials, states):
        assert trial.is_finished_ok
        assert trial.inputs.value.uuid == previous.uuid
        assert trial.inputs.target.uuid == root.inputs.target.uuid
        assert trial.inputs.stride.value == (2 if fast else 1)
        assert trial.outputs.value.value == expected
        creator = trial.outputs.value.base.links.get_incoming(link_type=LinkType.CREATE).one().node
        assert creator in trial.called
        previous = trial.outputs.value

    finalizer = finalizers[0]
    assert finalizer.is_finished_ok
    assert finalizer.inputs.value.uuid == previous.uuid
    assert finalizer.inputs.attempts.value == len(states)
    assert finalizer.inputs.mode.value == mode
    result = outputs['result']
    assert result.uuid == finalizer.outputs.result.uuid == root.outputs.result.uuid
    assert result.base.links.get_incoming(link_type=LinkType.CREATE).one().node in finalizer.called
    returning_nodes = result.base.links.get_incoming(link_type=LinkType.RETURN).all_nodes()
    assert root in returning_nodes
    assert finalizer in returning_nodes
    assert not root.base.links.get_outgoing(link_type=LinkType.CREATE).all()
