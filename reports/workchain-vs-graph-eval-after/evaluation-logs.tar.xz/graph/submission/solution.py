###########################################################################
# Copyright (c), The AiiDA team. All rights reserved.                     #
# This file is part of the AiiDA code.                                    #
#                                                                         #
# The code is hosted on GitHub at https://github.com/aiidateam/aiida-core #
# For further information on the license, see the LICENSE.txt file        #
# For further information please visit http://www.aiida.net               #
###########################################################################
"""Bounded adaptive relaxation with inline graph orchestration."""

from aiida.engine import graph, task
from tests.engine.processes.workflow_eval.collaborators import FinalizeWorkChain, TrialWorkChain

trial = task(TrialWorkChain)
finalize = task(FinalizeWorkChain)


@graph
def workflow(initial: int, target: int, max_steps: int, fast: bool):
    """Relax towards the target within a budget and forward the final report."""
    if fast:
        stride = 2
    else:
        stride = 1

    value = initial
    attempts = 0
    pending = False
    if value != target:
        pending = attempts < max_steps

    while pending:
        step = trial(value=value, target=target, stride=stride)
        value = step.value
        attempts = attempts + 1
        pending = False
        if value != target:
            pending = attempts < max_steps

    if value == target:
        mode = 'square'
    else:
        mode = 'unfinished'
    report = finalize(value=value, target=target, attempts=attempts, mode=mode)
    return {'result': report.result}
