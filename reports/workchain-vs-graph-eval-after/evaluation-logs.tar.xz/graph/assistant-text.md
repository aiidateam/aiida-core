I’ll use inline graph branches and a loop for orchestration, keeping state updates in `TrialWorkChain` and forwarding the finalizer’s result node unchanged.

Implemented `solution.py` using public `@graph` and collaborator tasks, with bounded iteration, inline branching, and unchanged result-node forwarding.

Added focused behavior and provenance tests in `test_solution.py`.

Test command:
`uv run --no-sync pytest --broker-backend=none -q tests/engine/processes/workflow_eval`

Result: **23 passed**, 1 event-loop deprecation warning. No blockers.