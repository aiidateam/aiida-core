###########################################################################
# Copyright (c), The AiiDA team. All rights reserved.                     #
# This file is part of the AiiDA code.                                    #
#                                                                         #
# The code is hosted on GitHub at https://github.com/aiidateam/aiida-core #
# For further information on the license, see the LICENSE.txt file        #
# For further information please visit http://www.aiida.net               #
###########################################################################
"""Bounded restart wrapper for the flaky collaborator."""

from aiida import orm
from aiida.engine import BaseRestartWorkChain, ProcessHandlerReport, process_handler, run_get_node, while_
from aiida.engine.processes import ProcessSpec

from fixtures.flaky_child import FlakyChild

__all__ = ('MAX_ITERATIONS', 'RestartWrapper', 'run_restart')

MAX_ITERATIONS = 5


class RestartWrapper(BaseRestartWorkChain):
    """Retry transient child failures with the base class's five-run limit."""

    _process_class = FlakyChild

    @classmethod
    def define(cls, spec: ProcessSpec) -> None:
        """Expose child ports and drive the standard restart phases."""
        super().define(spec)
        spec.expose_inputs(FlakyChild, include=('fail_until', 'fatal'))
        spec.expose_outputs(FlakyChild)
        spec.outline(
            cls.setup,
            while_(cls.should_run_process)(
                cls.run_process,
                cls.inspect_process,
            ),
            cls.results,
        )

    def setup(self) -> None:
        """Initialize the first attempt without changing the default retry cap."""
        super().setup()
        self.ctx.inputs = dict(self.exposed_inputs(FlakyChild))
        self.ctx.inputs['attempt'] = orm.Int(1)

    @process_handler(exit_codes=FlakyChild.exit_codes.ERROR_TRANSIENT)
    def handle_transient(self, node: orm.ProcessNode) -> ProcessHandlerReport:
        """Advance using the child's stored counter only for transient failures."""
        self.ctx.inputs['attempt'] = node.outputs.next_attempt
        return ProcessHandlerReport(do_break=True)


def run_restart(fail_until: int = 2, fatal: bool = False) -> orm.ProcessNode:
    """Run the wrapper in-process and return its process node.

    :param fail_until: Last attempt that should fail transiently.
    :param fatal: Whether the child should fail permanently instead.
    :return: The wrapper process node, including unsuccessful outcomes.
    """
    _, node = run_get_node(RestartWrapper, fail_until=orm.Int(fail_until), fatal=orm.Bool(fatal))
    return node
