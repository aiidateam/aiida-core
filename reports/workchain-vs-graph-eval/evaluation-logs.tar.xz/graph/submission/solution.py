###########################################################################
# Copyright (c), The AiiDA team. All rights reserved.                     #
# This file is part of the AiiDA code.                                    #
#                                                                         #
# The code is hosted on GitHub at https://github.com/aiidateam/aiida-core #
# For further information on the license, see the LICENSE.txt file        #
# For further information please visit http://www.aiida.net               #
###########################################################################
"""Bounded relaxation with inline graph orchestration and recorded child work."""

from aiida.engine import graph, task
from aiida.orm import Dict
from tests.engine.processes.workflow_eval.collaborators import FinalizeWorkChain, TrialWorkChain

trial = task(TrialWorkChain)
finalize = task(FinalizeWorkChain)


@graph
def workflow(initial: int, target: int, max_steps: int, fast: bool) -> Dict:
    """Relax towards the target within the budget, returning the finalizer's report."""
    # Inline expressions seed orchestration wires without calculation processes.
    attempts = 0 + 0
    value = initial
    if fast:
        stride = 1 + 1
    else:
        stride = 0 + 1

    running = attempts < max_steps
    if value == target:
        running = attempts < 0
    while running:
        (value,) = trial(value=value, target=target, stride=stride)
        attempts = attempts + 1
        running = attempts < max_steps
        if value == target:
            running = attempts < 0

    if value == target:
        report = finalize(value=value, target=target, attempts=attempts, mode='square')
    else:
        report = finalize(value=value, target=target, attempts=attempts, mode='unfinished')
    return report.result
