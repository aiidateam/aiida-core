# Instrumentation smoke checks

These two initial executions checked the standalone profiler before the matched experiment. They were not CPU-pinned and are excluded from the 78-run dataset, maxima, medians and summary. The matched experiment is recorded in the parent directory's runs.jsonl and summary.json.
