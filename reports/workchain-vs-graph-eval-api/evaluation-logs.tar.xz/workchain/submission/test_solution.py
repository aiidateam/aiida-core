###########################################################################
# Copyright (c), The AiiDA team. All rights reserved.                     #
# This file is part of the AiiDA code.                                    #
#                                                                         #
# The code is hosted on GitHub at https://github.com/aiidateam/aiida-core #
# For further information on the license, see the LICENSE.txt file        #
# For further information please visit http://www.aiida.net               #
###########################################################################
"""Behavior and provenance tests for the bounded relaxation WorkChain."""

import pytest

from aiida.common.links import LinkType
from aiida.engine import run_get_node
from aiida.orm import Bool, Dict, Int

from .collaborators import FinalizeWorkChain, TrialWorkChain
from .solution import workflow

pytestmark = [pytest.mark.presto, pytest.mark.usefixtures('aiida_profile_clean')]


@pytest.mark.parametrize(
    'initial,target,max_steps,fast,states',
    [
        pytest.param(0, 5, 8, True, [2, 4, 5], id='fast-no-overshoot'),
        pytest.param(0, 3, 3, False, [1, 2, 3], id='slow-exact-budget'),
        pytest.param(0, 7, 2, True, [2, 4], id='fast-exhaustion'),
        pytest.param(-3, 2, 2, False, [-2, -1], id='slow-exhaustion'),
        pytest.param(4, 4, 5, True, [], id='already-converged'),
        pytest.param(-2, -2, 0, False, [], id='already-converged-zero-budget'),
        pytest.param(1, 3, 0, True, [], id='zero-budget'),
        pytest.param(2, -3, 8, True, [0, -2, -3], id='fast-descending-negative'),
        pytest.param(-1, -4, 8, False, [-2, -3, -4], id='slow-descending-negative'),
    ],
)
def test_relaxation(initial: int, target: int, max_steps: int, fast: bool, states: list[int]) -> None:
    """Check exact reports, trial bounds, child inputs, and the full data-return chain."""
    inputs = {'initial': Int(initial), 'target': Int(target), 'max_steps': Int(max_steps), 'fast': Bool(fast)}
    outputs, node = run_get_node(workflow, **inputs)
    assert node.is_finished_ok
    assert set(outputs) == {'result'}
    assert isinstance(outputs['result'], Dict)
    value = states[-1] if states else initial
    converged = value == target
    assert outputs['result'].get_dict() == {
        'value': value,
        'target': target,
        'attempts': len(states),
        'converged': converged,
        'mode': 'square' if converged else 'unfinished',
        'score': value**2 if converged else -1,
    }

    children = node.base.links.get_outgoing(link_type=LinkType.CALL_WORK).all_nodes()
    trials = sorted((child for child in children if child.process_class is TrialWorkChain), key=lambda child: child.pk)
    finalizers = [child for child in children if child.process_class is FinalizeWorkChain]
    assert len(trials) == len(states)
    assert len(finalizers) == 1
    assert len(children) == len(states) + 1
    assert not node.base.links.get_outgoing(link_type=LinkType.CALL_CALC).all()

    previous = inputs['initial']
    for trial, expected in zip(trials, states):
        assert trial.is_finished_ok
        assert trial.inputs.value.uuid == previous.uuid
        assert trial.inputs.target.uuid == inputs['target'].uuid
        assert trial.inputs.stride.value == (2 if fast else 1)
        current = trial.outputs.value
        assert current.value == expected
        assert abs(current.value - target) < abs(previous.value - target)
        assert min(previous.value, target) <= current.value <= max(previous.value, target)
        creator = current.base.links.get_incoming(link_type=LinkType.CREATE).one().node
        assert creator.caller.uuid == trial.uuid
        previous = current

    finalizer = finalizers[0]
    assert finalizer.is_finished_ok
    assert finalizer.inputs.value.uuid == previous.uuid
    assert finalizer.inputs.target.uuid == inputs['target'].uuid
    assert finalizer.inputs.attempts.value == len(states)
    assert finalizer.inputs.mode.value == ('square' if converged else 'unfinished')
    result = outputs['result']
    assert result.uuid == finalizer.outputs.result.uuid == node.outputs.result.uuid
    returning_nodes = result.base.links.get_incoming(link_type=LinkType.RETURN).all_nodes()
    assert {parent.uuid for parent in returning_nodes} == {node.uuid, finalizer.uuid}
    creator = result.base.links.get_incoming(link_type=LinkType.CREATE).one().node
    assert creator.caller.uuid == finalizer.uuid
