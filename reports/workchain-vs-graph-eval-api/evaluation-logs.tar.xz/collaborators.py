###########################################################################
# Copyright (c), The AiiDA team. All rights reserved.                     #
# This file is part of the AiiDA code.                                    #
#                                                                         #
# The code is hosted on GitHub at https://github.com/aiidateam/aiida-core #
# For further information on the license, see the LICENSE.txt file        #
# For further information please visit http://www.aiida.net               #
###########################################################################
"""Fixed scientific collaborators for the paired authoring evaluation."""

from aiida.engine import WorkChain, calcfunction
from aiida.orm import Dict, Int, Str


@calcfunction
def advance(value: Int, target: Int, stride: Int) -> Int:
    """Move towards the target without overshooting."""
    delta = target.value - value.value
    change = min(abs(delta), stride.value)
    return Int(value.value + (change if delta > 0 else -change))


@calcfunction
def summarize(value: Int, target: Int, attempts: Int, mode: Str) -> Dict:
    """Record a report with a branch-selected scientific score."""
    return Dict(dict={
        'value': value.value,
        'target': target.value,
        'attempts': attempts.value,
        'converged': value.value == target.value,
        'mode': mode.value,
        'score': value.value**2 if mode.value == 'square' else -1,
    })


class TrialWorkChain(WorkChain):
    """Run one scientific update."""

    @classmethod
    def define(cls, spec):
        super().define(spec)
        for name in ('value', 'target', 'stride'):
            spec.input(name, valid_type=Int)
        spec.output('value', valid_type=Int)
        spec.outline(cls.compute)

    def compute(self):
        self.out('value', advance(self.inputs.value, self.inputs.target, self.inputs.stride))


class FinalizeWorkChain(WorkChain):
    """Record the terminal summary without doing orchestration."""

    @classmethod
    def define(cls, spec):
        super().define(spec)
        for name in ('value', 'target', 'attempts'):
            spec.input(name, valid_type=Int)
        spec.input('mode', valid_type=Str)
        spec.output('result', valid_type=Dict)
        spec.outline(cls.compute)

    def compute(self):
        self.out('result', summarize(
            self.inputs.value, self.inputs.target, self.inputs.attempts, self.inputs.mode
        ))
