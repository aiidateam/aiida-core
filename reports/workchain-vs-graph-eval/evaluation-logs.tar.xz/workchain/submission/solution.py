###########################################################################
# Copyright (c), The AiiDA team. All rights reserved.                     #
# This file is part of the AiiDA code.                                    #
#                                                                         #
# The code is hosted on GitHub at https://github.com/aiidateam/aiida-core #
# For further information on the license, see the LICENSE.txt file        #
# For further information please visit http://www.aiida.net               #
###########################################################################
"""Bounded relaxation using provenance-preserving child workflows."""

from aiida.engine import ToContext, WorkChain, if_, while_
from aiida.engine.processes.workchains.workchain import WorkChainSpec
from aiida.orm import Bool, Dict, Int, Str

from .collaborators import FinalizeWorkChain, TrialWorkChain


class RelaxWorkChain(WorkChain):
    """Run serial trials up to a budget and finalize the terminal state."""

    @classmethod
    def define(cls, spec: WorkChainSpec) -> None:
        """Define the inputs, returned report, and bounded execution outline."""
        super().define(spec)
        for name in ('initial', 'target', 'max_steps'):
            spec.input(name, valid_type=Int)
        spec.input('fast', valid_type=Bool)
        spec.output('result', valid_type=Dict)
        spec.outline(
            cls.setup,
            while_(cls.needs_trial)(cls.run_trial, cls.inspect_trial),
            if_(cls.is_converged)(cls.select_success).else_(cls.select_unfinished),
            cls.run_finalize,
            cls.results,
        )

    def setup(self) -> None:
        """Initialize orchestration state and select the trial stride."""
        self.ctx.value = self.inputs.initial
        self.ctx.attempts = 0
        self.ctx.stride = Int(2 if self.inputs.fast.value else 1)

    def is_converged(self) -> bool:
        """Return whether the latest child value reaches the target."""
        return self.ctx.value.value == self.inputs.target.value

    def needs_trial(self) -> bool:
        """Continue only while unconverged and within the trial budget."""
        return not self.is_converged() and self.ctx.attempts < self.inputs.max_steps.value

    def run_trial(self) -> ToContext:
        """Submit and await exactly one scientific update."""
        return ToContext(
            trial=self.submit(
                TrialWorkChain,
                value=self.ctx.value,
                target=self.inputs.target,
                stride=self.ctx.stride,
            )
        )

    def inspect_trial(self) -> None:
        """Keep the child's existing output and count the completed attempt."""
        self.ctx.value = self.ctx.trial.outputs.value
        self.ctx.attempts += 1

    def select_success(self) -> None:
        """Select successful postprocessing in the root."""
        self.ctx.mode = Str('square')

    def select_unfinished(self) -> None:
        """Select normal budget-exhaustion postprocessing in the root."""
        self.ctx.mode = Str('unfinished')

    def run_finalize(self) -> ToContext:
        """Delegate report creation to exactly one finalizer."""
        return ToContext(
            finalizer=self.submit(
                FinalizeWorkChain,
                value=self.ctx.value,
                target=self.inputs.target,
                attempts=Int(self.ctx.attempts),
                mode=self.ctx.mode,
            )
        )

    def results(self) -> None:
        """Return the finalizer's report without creating or copying data."""
        self.out('result', self.ctx.finalizer.outputs.result)


workflow = RelaxWorkChain
