I’ll check the supported graph control flow, implement the orchestration, and add tests for behavior and provenance.

The focused tests pass, including zero-trial cases and result-node provenance. The graph layer requires initialized loop variables and rejects literal assignments, so counters and stride use inline expressions; the final branch supplies each mode directly to the finalizer. I’ll now run the full requested suite.

Implemented `solution.py` using public `@graph` and collaborator tasks, with bounded sequential trials and branch-selected finalization preserving result-node identity.

Added 11 behavior/provenance tests in `test_solution.py`.

Verification:
- `uv run --no-sync pytest --broker-backend=none -q tests/engine/processes/workflow_eval` — **24 passed**, 1 event-loop deprecation warning.
- Pre-commit checks passed.

No blockers.