###########################################################################
# Copyright (c), The AiiDA team. All rights reserved.                     #
# This file is part of the AiiDA code.                                    #
#                                                                         #
# The code is hosted on GitHub at https://github.com/aiidateam/aiida-core #
# For further information on the license, see the LICENSE.txt file        #
# For further information please visit http://www.aiida.net               #
###########################################################################
"""Behavior and provenance checks for bounded relaxation."""

import pytest

from aiida.common.links import LinkType
from aiida.engine import run_get_node
from aiida.orm import Bool, Int
from tests.engine.processes.workflow_eval.collaborators import FinalizeWorkChain, TrialWorkChain
from tests.engine.processes.workflow_eval.solution import workflow

pytestmark = [pytest.mark.presto, pytest.mark.usefixtures('aiida_profile_clean')]


@pytest.mark.parametrize(
    'initial,target,budget,fast,expected,attempts',
    [
        (0, 5, 10, False, 5, 5),
        (0, 5, 3, True, 5, 3),
        (0, 5, 2, False, 2, 2),
        (0, 5, 2, True, 4, 2),
        (7, 7, 10, False, 7, 0),
        (-3, -3, 0, True, -3, 0),
        (4, -3, 4, True, -3, 4),
        (-1, -4, 3, False, -4, 3),
        (-5, -2, 2, True, -2, 2),
        (3, -2, 0, False, 3, 0),
    ],
)
def test_relaxation(initial, target, budget, fast, expected, attempts):
    """Check bounded iteration, branch selection, and unchanged result provenance."""
    outputs, root = run_get_node(
        workflow, initial=Int(initial), target=Int(target), max_steps=Int(budget), fast=Bool(fast)
    )
    assert root.is_finished_ok
    converged = expected == target
    assert outputs['result'].get_dict() == {
        'value': expected,
        'target': target,
        'attempts': attempts,
        'converged': converged,
        'mode': 'square' if converged else 'unfinished',
        'score': expected**2 if converged else -1,
    }

    children = root.base.links.get_outgoing(link_type=LinkType.CALL_WORK).all_nodes()
    trials = sorted((child for child in children if child.process_class is TrialWorkChain), key=lambda node: node.pk)
    finalizers = [child for child in children if child.process_class is FinalizeWorkChain]
    assert len(children) == attempts + 1
    assert len(trials) == attempts
    assert len(finalizers) == 1
    previous = root.inputs.graph_inputs.initial
    for child in trials:
        assert child.is_finished_ok
        assert child.inputs.value.uuid == previous.uuid
        assert child.inputs.stride.value == (2 if fast else 1)
        current = child.outputs.value
        assert min(previous.value, target) <= current.value <= max(previous.value, target)
        assert abs(current.value - previous.value) <= child.inputs.stride.value
        previous = current
    finalizer = finalizers[0]
    assert finalizer.is_finished_ok
    assert finalizer.inputs.value.uuid == previous.uuid
    assert finalizer.inputs.attempts.value == attempts
    assert outputs['result'].uuid == finalizer.outputs.result.uuid
    assert root.outputs.result.uuid == outputs['result'].uuid
    creator = outputs['result'].creator
    assert creator.process_label == 'summarize'
    assert creator.caller.uuid == finalizer.uuid
    assert not root.base.links.get_outgoing(link_type=LinkType.CREATE).all()
