###########################################################################
# Copyright (c), The AiiDA team. All rights reserved.                     #
# This file is part of the AiiDA code.                                    #
#                                                                         #
# The code is hosted on GitHub at https://github.com/aiidateam/aiida-core #
# For further information on the license, see the LICENSE.txt file        #
# For further information please visit http://www.aiida.net               #
###########################################################################
"""Exercise bounded graph orchestration with the real scientific collaborators."""

import pytest

from aiida.common.links import LinkType
from aiida.engine import run_get_node
from aiida.orm import Bool, Dict, Int

from .solution import workflow

pytestmark = pytest.mark.presto


def test_build() -> None:
    """Validate graph syntax and contracts before executing children."""
    assert workflow.build() is None


@pytest.mark.usefixtures('aiida_profile_clean')
@pytest.mark.parametrize('fast', [False, True], ids=['slow', 'fast'])
@pytest.mark.parametrize(
    'initial,target,budget',
    [
        pytest.param(0, 5, 8, id='converges-with-odd-distance'),
        pytest.param(0, 9, 2, id='exhausted'),
        pytest.param(-3, -3, 5, id='initially-converged'),
        pytest.param(2, -3, 8, id='descending-negative'),
        pytest.param(-8, -3, 8, id='ascending-negative'),
        pytest.param(0, 5, 0, id='zero-budget'),
        pytest.param(4, 4, 0, id='converged-zero-budget'),
        pytest.param(0, 4, 4, id='budget-boundary'),
    ],
)
def test_report_and_provenance(initial: int, target: int, budget: int, fast: bool) -> None:
    """Check terminal reports, exact child placement, no overshoot and existing-node returns."""
    inputs = {'initial': Int(initial), 'target': Int(target), 'max_steps': Int(budget), 'fast': Bool(fast)}
    outputs, root = run_get_node(workflow, **inputs)
    assert root.is_finished_ok
    stride = 2 if fast else 1
    distance = abs(target - initial)
    attempts = min(budget, (distance + stride - 1) // stride)
    direction = 1 if target >= initial else -1
    value = initial + direction * min(distance, attempts * stride)
    converged = value == target
    mode = 'square' if converged else 'unfinished'
    result = outputs['result']
    assert isinstance(result, Dict)
    assert result.get_dict() == {
        'value': value,
        'target': target,
        'attempts': attempts,
        'converged': converged,
        'mode': mode,
        'score': value**2 if converged else -1,
    }
    for name, input_node in inputs.items():
        assert root.inputs[name].uuid == input_node.uuid

    children = root.base.links.get_outgoing(link_type=LinkType.CALL_WORK).all_nodes()
    trials = sorted((child for child in children if child.process_label == 'TrialWorkChain'), key=lambda n: n.pk)
    finalizers = [child for child in children if child.process_label == 'FinalizeWorkChain']
    assert len(children) == attempts + 1
    assert len(trials) == attempts
    assert len(finalizers) == 1
    previous = inputs['initial']
    for child in trials:
        assert child.is_finished_ok
        assert child.inputs.value.uuid == previous.uuid
        assert child.inputs.target.uuid == inputs['target'].uuid
        assert child.inputs.stride.value == stride
        next_value = child.outputs.value
        assert min(initial, target) <= next_value.value <= max(initial, target)
        assert abs(next_value.value - target) < abs(previous.value - target)
        assert abs(next_value.value - previous.value) <= stride
        assert next_value.creator.process_label == 'advance'
        previous = next_value

    finalizer = finalizers[0]
    assert finalizer.is_finished_ok
    assert finalizer.inputs.value.uuid == previous.uuid
    assert finalizer.inputs.target.uuid == inputs['target'].uuid
    assert finalizer.inputs.attempts.value == attempts
    assert finalizer.inputs.mode.value == mode
    assert result.uuid == finalizer.outputs.result.uuid
    assert result.creator.process_label == 'summarize'
    assert result.creator in finalizer.called_descendants
    assert root.base.links.get_outgoing(link_type=LinkType.CREATE).all() == []
    returned = root.base.links.get_outgoing(link_type=LinkType.RETURN).all()
    assert len(returned) == 1
    assert returned[0].link_label == 'result'
    assert returned[0].node.uuid == result.uuid
