###########################################################################
# Copyright (c), The AiiDA team. All rights reserved.                     #
# This file is part of the AiiDA code.                                    #
#                                                                         #
# The code is hosted on GitHub at https://github.com/aiidateam/aiida-core #
# For further information on the license, see the LICENSE.txt file        #
# For further information please visit http://www.aiida.net               #
###########################################################################
"""Build the human-readable report from saved metrics and independent test results."""

import json
from pathlib import Path
import subprocess
import xml.etree.ElementTree as ET

REPORT = Path(__file__).resolve().parent


def main() -> None:
    results = json.loads((REPORT / 'results.json').read_text())
    rows = []
    for arm, result in results.items():
        root = ET.parse(REPORT / arm / 'validation.xml').getroot()
        cases = list(root.iter('testcase'))
        failures = sum(case.find('failure') is not None or case.find('error') is not None for case in cases)
        passed = len(cases) - failures - sum(case.find('skipped') is not None for case in cases)
        acceptance = [case for case in cases if 'test_acceptance' in case.get('classname', '')]
        acceptance_passed = sum(
            case.find('failure') is None and case.find('error') is None
            and case.find('skipped') is None for case in acceptance
        )
        usage = result['usage']
        rows.append(
            f"| {arm} | {result['wall_seconds']:.1f} | {usage['input']:,} | {usage['output']:,} | "
            f"{usage['cacheRead']:,} | {usage['totalTokens']:,} | "
            f"{acceptance_passed}/{len(acceptance)} | {passed}/{len(cases)} |"
        )
        sessions = list((REPORT / arm / 'sessions').glob('*.jsonl'))
        if len(sessions) == 1:
            exported = subprocess.run(
                ['pi', '--no-extensions', '--no-mcp', '--export', str(sessions[0]),
                 str(REPORT / arm / 'session.html')],
                capture_output=True, text=True, check=False,
            )
            (REPORT / arm / 'export.log').write_text(exported.stdout + exported.stderr)
    run = json.loads((REPORT / 'run.json').read_text())
    text = f'''# WorkChain vs graph authoring: paired agent evaluation

## Task and setup

Implement bounded adaptive relaxation: choose a stride, repeatedly submit a scientific child WorkChain until convergence or a budget limit, branch on the outcome, then submit a finalizer and return its existing report node. The same fixed scientific collaborators, input/output contract and 13 acceptance cases are supplied to both arms. See [task.md](task.md).

Two fresh **Pi OS processes**, separate source snapshots/Git repositories and new sessions; no inherited conversation, pilot solution or cross-agent context. Same model: `{run['provider']}/{run['model']}`, thinking `{run['thinking']}`. Concurrent execution, 900-second limit per arm. Snapshots include the current dirty working tree, not just HEAD; file hashes are in [baseline-manifest.json](baseline-manifest.json).

## Final measured results

| Arm | Solve time (s) | Input tokens | Output tokens | Cached-read tokens | Total tokens | Common acceptance | All tests |
|---|---:|---:|---:|---:|---:|---:|---:|
''' + '\n'.join(rows) + '''

Solve time includes the agent's exploration, reasoning, edits and its own tests, but excludes the evaluator's subsequent validation. Tokens are cumulative usage across model calls; total includes cached context. Input/output alone are not the total. Detailed costs, calls and validation timings are in each arm's metrics JSON.

Both submissions comply with their assigned orchestration style and preserve the returned node's identity. See [review.md](review.md). The all-tests counts differ because each agent wrote its own additional tests; the common acceptance suite is identical. [audit.json](audit.json) independently cross-checks event usage totals against persisted sessions and confirms distinct fresh session IDs.

This is one task and one final run per style, not statistically significant evidence that either style is generally better. Tests are visible rather than held out. See [evaluator-notes.md](evaluator-notes.md) for isolation limits and the excluded pilot/evaluator correction history.

## Artifacts

Each of `workchain/` and `graph/` contains:

- `prompt.md`, `invocation.json`: complete initial task, style constraint and process invocation.
- `events.jsonl`: complete streamed agent events including tool calls/results and usage.
- `sessions/*.jsonl`, `session.html`: persisted full session and browsable export.
- `stderr.log`, `assistant-text.md`: process diagnostics and all assistant text (not just the final response).
- `metrics.json`: measured time, token categories, exit codes, model and fixed-file integrity.
- `submission/`: complete submitted implementation, agent tests and shared evaluator/collaborators.
- `solution.patch`: changes relative to its starting snapshot.
- `validation.log`, `validation.xml`: independently rerun acceptance and agent-authored tests.

Shared files: `collaborators.py`, `test_acceptance.py`, `run_eval.py`, `summarize.py`, `run.json`, `results.json`. The excluded first pair's complete artifacts remain under `pilot/`.

## Reproduce with fresh agents

Use a new empty report folder to avoid overwriting these results:

```bash
mkdir -p reports/workchain-vs-graph-eval-rerun
cp reports/workchain-vs-graph-eval/{run_eval.py,summarize.py,task.md,collaborators.py,test_acceptance.py} reports/workchain-vs-graph-eval-rerun/
uv run --no-sync python reports/workchain-vs-graph-eval-rerun/run_eval.py
uv run --no-sync python reports/workchain-vs-graph-eval-rerun/summarize.py
```

Requires the already-installed project environment, `pi` and configured provider credentials. `PI_PROVIDER`, `PI_MODEL` and `PI_REASONING_LEVEL` select the shared model settings (defaults are recorded in the runner). Workspaces are retained under the temporary path recorded in `run.json`. The installed dependency environment is shared, but `PYTHONPATH` selects each workspace's own source.
'''
    (REPORT / 'README.md').write_text(text)


if __name__ == '__main__':
    main()
