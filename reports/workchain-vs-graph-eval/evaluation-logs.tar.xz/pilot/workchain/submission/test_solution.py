###########################################################################
# Copyright (c), The AiiDA team. All rights reserved.                     #
# This file is part of the AiiDA code.                                    #
#                                                                         #
# The code is hosted on GitHub at https://github.com/aiidateam/aiida-core #
# For further information on the license, see the LICENSE.txt file        #
# For further information please visit http://www.aiida.net               #
###########################################################################
"""Focused boundary and provenance tests for the bounded relaxation workflow."""

import pytest

from aiida.common.links import LinkType
from aiida.engine import run_get_node
from aiida.orm import Bool, Int

from .solution import workflow

pytestmark = [pytest.mark.presto, pytest.mark.usefixtures('aiida_profile_clean')]


@pytest.mark.parametrize(
    'initial,target,budget,fast,states,converged',
    [
        pytest.param(0, 3, 5, False, [1, 2, 3], True, id='slow-convergence'),
        pytest.param(0, 3, 5, True, [2, 3], True, id='fast-no-overshoot'),
        pytest.param(0, 4, 2, False, [1, 2], False, id='slow-exhaustion'),
        pytest.param(0, 7, 2, True, [2, 4], False, id='fast-exhaustion'),
        pytest.param(-4, -4, 0, False, [], True, id='initially-converged-zero-budget'),
        pytest.param(-4, -4, 5, True, [], True, id='initially-converged-positive-budget'),
        pytest.param(3, -1, 0, True, [], False, id='zero-budget-unfinished'),
        pytest.param(2, -3, 3, True, [0, -2, -3], True, id='descending-through-zero'),
        pytest.param(-2, -5, 3, False, [-3, -4, -5], True, id='negative-slow'),
        pytest.param(-8, -3, 3, True, [-6, -4, -3], True, id='negative-ascending'),
    ],
)
def test_relaxation(initial, target, budget, fast, states, converged):
    """Check the exact sequence and that every scientific result retains its creator."""
    outputs, root = run_get_node(
        workflow, initial=Int(initial), target=Int(target), max_steps=Int(budget), fast=Bool(fast)
    )
    value = states[-1] if states else initial
    mode = 'square' if converged else 'unfinished'
    assert root.is_finished_ok
    assert outputs['result'].get_dict() == {
        'value': value,
        'target': target,
        'attempts': len(states),
        'converged': converged,
        'mode': mode,
        'score': value**2 if converged else -1,
    }

    children = root.base.links.get_outgoing(link_type=LinkType.CALL_WORK).all_nodes()
    trials = sorted(
        (child for child in children if child.process_label == 'TrialWorkChain'), key=lambda child: child.pk
    )
    finalizers = [child for child in children if child.process_label == 'FinalizeWorkChain']
    assert len(children) == len(states) + 1
    assert len(trials) == len(states)
    assert len(finalizers) == 1
    previous = root.inputs.initial
    for trial, expected in zip(trials, states):
        assert trial.is_finished_ok
        assert trial.inputs.value.uuid == previous.uuid
        assert trial.inputs.target.uuid == root.inputs.target.uuid
        assert trial.inputs.stride.value == (2 if fast else 1)
        assert trial.outputs.value.value == expected
        creator = trial.outputs.value.base.links.get_incoming(link_type=LinkType.CREATE).one().node
        assert creator in trial.called
        previous = trial.outputs.value

    finalizer = finalizers[0]
    assert finalizer.is_finished_ok
    assert finalizer.inputs.value.uuid == previous.uuid
    assert finalizer.inputs.target.uuid == root.inputs.target.uuid
    assert finalizer.inputs.attempts.value == len(states)
    assert finalizer.inputs.mode.value == mode
    assert outputs['result'].uuid == finalizer.outputs.result.uuid
    assert root.outputs.result.uuid == outputs['result'].uuid
    assert root.base.links.get_outgoing(link_type=LinkType.CREATE).all() == []
    creator = outputs['result'].base.links.get_incoming(link_type=LinkType.CREATE).one().node
    assert creator in finalizer.called
    returners = outputs['result'].base.links.get_incoming(link_type=LinkType.RETURN).all_nodes()
    assert {node.uuid for node in returners} == {root.uuid, finalizer.uuid}
