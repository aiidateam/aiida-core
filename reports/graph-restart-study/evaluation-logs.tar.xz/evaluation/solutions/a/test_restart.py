"""Local black-box checks for the restart wrapper."""

import pytest

from aiida.common.links import LinkType

from restart_solution import MAX_ITERATIONS, run_restart

pytest_plugins = ['aiida.tools.pytest_fixtures']


@pytest.mark.parametrize(
    ('fail_until', 'fatal', 'runs', 'status'),
    [(2, False, 3, 0), (10, False, MAX_ITERATIONS, 401), (2, True, 1, 402), (0, False, 1, 0), (4, False, 5, 0)],
)
def test_restart(aiida_profile, fail_until, fatal, runs, status):
    node = run_restart(fail_until, fatal)
    children = sorted(node.called, key=lambda child: child.inputs.attempt.value)
    assert len(children) == runs
    assert node.exit_status == status
    assert [child.inputs.attempt.value for child in children] == list(range(1, runs + 1))
    if status == 0:
        assert node.outputs.result.value == runs * 10
        assert node.outputs.result.pk == children[-1].outputs.result.pk
        assert node.base.links.get_outgoing(link_type=LinkType.RETURN).get_node_by_label('result').pk == children[-1].outputs.result.pk
    else:
        assert 'result' not in node.outputs
