I’ll use an outline-driven WorkChain that keeps trial outputs as the current state and returns the finalizer’s Dict unchanged. Tests will check loop boundaries and provenance.


Implemented `solution.py` with a bounded, sequential WorkChain, root-level branching, and unchanged finalizer-output forwarding. Added boundary and provenance tests in `test_solution.py`.

Tests:
`uv run --no-sync pytest --broker-backend=none -q tests/engine/processes/workflow_eval`

**22 passed**, 1 deprecation warning.

No implementation blockers. Ruff checking was unavailable because Ruff is not installed.