###########################################################################
# Copyright (c), The AiiDA team. All rights reserved.                     #
# This file is part of the AiiDA code.                                    #
#                                                                         #
# The code is hosted on GitHub at https://github.com/aiidateam/aiida-core #
# For further information on the license, see the LICENSE.txt file        #
# For further information please visit http://www.aiida.net               #
###########################################################################
"""Bounded relaxation with scientific updates delegated to child workflows."""

from aiida.engine import ProcessSpec, ToContext, WorkChain, if_, while_
from aiida.orm import Bool, Dict, Int, Str

from .collaborators import FinalizeWorkChain, TrialWorkChain


class RelaxWorkChain(WorkChain):
    """Relax an integer state within a fixed trial budget and return its report."""

    @classmethod
    def define(cls, spec: ProcessSpec) -> None:
        super().define(spec)
        for name in ('initial', 'target', 'max_steps'):
            spec.input(name, valid_type=Int)
        spec.input('fast', valid_type=Bool)
        spec.output('result', valid_type=Dict)
        spec.outline(
            cls.setup,
            while_(cls.should_run_trial)(cls.run_trial, cls.inspect_trial),
            if_(cls.is_converged)(cls.select_success).else_(cls.select_unfinished),
            cls.finalize,
            cls.publish,
        )

    def setup(self) -> None:
        self.ctx.value = self.inputs.initial
        self.ctx.attempts = 0
        self.ctx.stride = Int(2 if self.inputs.fast.value else 1)

    def is_converged(self) -> bool:
        return self.ctx.value.value == self.inputs.target.value

    def should_run_trial(self) -> bool:
        return not self.is_converged() and self.ctx.attempts < self.inputs.max_steps.value

    def run_trial(self) -> ToContext:
        return ToContext(
            trial=self.submit(
                TrialWorkChain,
                value=self.ctx.value,
                target=self.inputs.target,
                stride=self.ctx.stride,
            )
        )

    def inspect_trial(self) -> None:
        self.ctx.value = self.ctx.trial.outputs.value
        self.ctx.attempts += 1

    def select_success(self) -> None:
        self.ctx.mode = Str('square')

    def select_unfinished(self) -> None:
        self.ctx.mode = Str('unfinished')

    def finalize(self) -> ToContext:
        return ToContext(
            finalizer=self.submit(
                FinalizeWorkChain,
                value=self.ctx.value,
                target=self.inputs.target,
                attempts=Int(self.ctx.attempts),
                mode=self.ctx.mode,
            )
        )

    def publish(self) -> None:
        self.out('result', self.ctx.finalizer.outputs.result)


workflow = RelaxWorkChain
