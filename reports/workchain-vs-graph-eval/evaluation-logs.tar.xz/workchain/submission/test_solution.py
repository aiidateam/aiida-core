###########################################################################
# Copyright (c), The AiiDA team. All rights reserved.                     #
# This file is part of the AiiDA code.                                    #
#                                                                         #
# The code is hosted on GitHub at https://github.com/aiidateam/aiida-core #
# For further information on the license, see the LICENSE.txt file        #
# For further information please visit http://www.aiida.net               #
###########################################################################
"""Exercise bounded relaxation with real trial and finalization processes."""

import pytest

from aiida.common.links import LinkType
from aiida.engine import run_get_node
from aiida.orm import Bool, Int

from .collaborators import FinalizeWorkChain, TrialWorkChain
from .solution import workflow


@pytest.mark.parametrize(
    'initial,target,budget,fast,states',
    [
        pytest.param(0, 5, 8, True, [2, 4, 5], id='fast-converges-no-overshoot'),
        pytest.param(0, 3, 3, False, [1, 2, 3], id='slow-converges-at-budget'),
        pytest.param(0, 7, 2, True, [2, 4], id='fast-exhausted'),
        pytest.param(0, 7, 2, False, [1, 2], id='slow-exhausted'),
        pytest.param(-3, -3, 4, True, [], id='already-converged'),
        pytest.param(-3, -3, 0, False, [], id='already-converged-zero-budget'),
        pytest.param(4, -2, 0, True, [], id='zero-budget-unfinished'),
        pytest.param(2, -3, 9, True, [0, -2, -3], id='fast-descending-negative'),
        pytest.param(-1, -4, 5, False, [-2, -3, -4], id='slow-descending-negative'),
        pytest.param(-5, -2, 5, True, [-3, -2], id='negative-ascending'),
    ],
)
def test_relaxation(aiida_profile_clean, initial, target, budget, fast, states):
    """Check reports, exact trial transitions, and the creator/return link chain."""
    outputs, root = run_get_node(
        workflow, initial=Int(initial), target=Int(target), max_steps=Int(budget), fast=Bool(fast)
    )
    value = states[-1] if states else initial
    converged = value == target
    assert root.is_finished_ok
    assert set(outputs) == {'result'}
    assert outputs['result'].get_dict() == {
        'value': value,
        'target': target,
        'attempts': len(states),
        'converged': converged,
        'mode': 'square' if converged else 'unfinished',
        'score': value**2 if converged else -1,
    }

    children = root.base.links.get_outgoing(link_type=LinkType.CALL_WORK).all_nodes()
    trials = sorted((child for child in children if child.process_class is TrialWorkChain), key=lambda node: node.pk)
    finalizers = [child for child in children if child.process_class is FinalizeWorkChain]
    assert len(children) == len(states) + 1
    assert len(trials) == len(states)
    assert len(finalizers) == 1
    previous = root.inputs.initial
    for trial, expected in zip(trials, states):
        assert trial.is_finished_ok
        assert trial.inputs.value.uuid == previous.uuid
        assert trial.inputs.target.uuid == root.inputs.target.uuid
        assert trial.inputs.stride.value == (2 if fast else 1)
        assert trial.outputs.value.value == expected
        previous = trial.outputs.value

    finalizer = finalizers[0]
    assert finalizer.is_finished_ok
    assert finalizer.inputs.value.uuid == previous.uuid
    assert finalizer.inputs.target.uuid == root.inputs.target.uuid
    assert finalizer.inputs.attempts.value == len(states)
    assert finalizer.inputs.mode.value == ('square' if converged else 'unfinished')
    result = outputs['result']
    assert result.uuid == finalizer.outputs.result.uuid
    assert result.uuid == root.outputs.result.uuid
    returns = result.base.links.get_incoming(link_type=LinkType.RETURN).all()
    assert {(link.node.uuid, link.link_label) for link in returns} == {
        (root.uuid, 'result'), (finalizer.uuid, 'result')
    }
    creator = result.base.links.get_incoming(link_type=LinkType.CREATE).one().node
    assert creator.process_label == 'summarize'
    assert creator.caller.uuid == finalizer.uuid
    assert not root.base.links.get_outgoing(link_type=LinkType.CREATE).all()
