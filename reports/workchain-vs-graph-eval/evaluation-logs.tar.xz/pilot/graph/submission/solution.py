###########################################################################
# Copyright (c), The AiiDA team. All rights reserved.                     #
# This file is part of the AiiDA code.                                    #
#                                                                         #
# The code is hosted on GitHub at https://github.com/aiidateam/aiida-core #
# For further information on the license, see the LICENSE.txt file        #
# For further information please visit http://www.aiida.net               #
###########################################################################
"""Bounded adaptive relaxation using inline graph orchestration."""

from aiida.engine import graph, task
from aiida.orm import Dict

from .collaborators import FinalizeWorkChain, TrialWorkChain

trial = task(TrialWorkChain)
finalize = task(FinalizeWorkChain)


@graph
def workflow(initial: int, target: int, max_steps: int, fast: bool) -> Dict:
    """Relax towards the target within the trial budget and return its report."""
    attempts = max_steps - max_steps
    if fast:
        stride = attempts + 2
    else:
        stride = attempts + 1
    value = initial
    retry = attempts < max_steps
    if value == target:
        retry = attempts < 0
    while retry:
        value, = trial(value=value, target=target, stride=stride)
        attempts = attempts + 1
        retry = attempts < max_steps
        if value == target:
            retry = attempts < 0
    if value == target:
        report = finalize(value=value, target=target, attempts=attempts, mode='square')
    else:
        report = finalize(value=value, target=target, attempts=attempts, mode='unfinished')
    return report.result
