I’ll implement the loop and mode selection in one WorkChain, then add tests for boundary cases and provenance.


The 10 new tests pass, including provenance checks. All 13 acceptance cases fail at `root.inputs.get(...)`: AiiDA’s input link manager has no `get` method. I’ll leave the acceptance tests and infrastructure unchanged, as required.


Implemented `solution.py` with a conventional WorkChain: bounded sequential trials, root-level branching, and direct return of the finalizer’s existing Dict.

Added `test_solution.py` covering boundaries, both speeds, negative/descending values, and provenance.

Tests:
- `uv run --no-sync pytest --broker-backend=none -q tests/engine/processes/workflow_eval` — **10 passed, 13 failed**. Acceptance failures call unsupported `root.inputs.get(...)`.
- Same command targeting `test_solution.py` — **10 passed**.

Blockers: acceptance-test API error; Ruff unavailable. No collaborators, acceptance tests, or infrastructure were edited by me.