I’ll use the graph’s inline control flow for stride selection, the bounded loop, and final branching, with the supplied WorkChains handling all scientific calculations. Tests will check reports, trial counts, and provenance.


Implemented `solution.py` using `@graph` and the supplied WorkChain tasks. Added `test_solution.py` covering convergence, exhaustion, edge cases, both speeds, and provenance identity.

Tests:
`uv run --no-sync pytest --broker-backend=none -q tests/engine/processes/workflow_eval`

**30 passed**, with one event-loop deprecation warning.

No implementation blockers. Ruff checks could not run because Ruff is not installed.