###########################################################################
# Copyright (c), The AiiDA team. All rights reserved.                     #
# This file is part of the AiiDA code.                                    #
#                                                                         #
# The code is hosted on GitHub at https://github.com/aiidateam/aiida-core #
# For further information on the license, see the LICENSE.txt file        #
# For further information please visit http://www.aiida.net               #
###########################################################################
"""Behavior and provenance tests for adaptive relaxation."""

import pytest

from aiida.common.links import LinkType
from aiida.engine import run_get_node
from aiida.orm import Bool, Int

from .collaborators import FinalizeWorkChain, TrialWorkChain
from .solution import workflow

pytestmark = [pytest.mark.presto, pytest.mark.usefixtures('aiida_profile_clean')]


@pytest.mark.parametrize('fast', [False, True])
@pytest.mark.parametrize(
    'initial,target,budget',
    [
        pytest.param(0, 5, 9, id='ascending-convergence'),
        pytest.param(0, 9, 2, id='exhaustion'),
        pytest.param(-4, -4, 0, id='initially-converged-empty-budget'),
        pytest.param(-4, -4, 7, id='initially-converged-with-budget'),
        pytest.param(2, -3, 0, id='empty-budget'),
        pytest.param(3, -4, 8, id='descending-across-zero'),
        pytest.param(-2, -7, 5, id='descending-negative'),
        pytest.param(-7, -2, 5, id='ascending-negative'),
        pytest.param(0, 4, 2, id='last-attempt-convergence-or-exhaustion'),
    ],
)
def test_relaxation(initial: int, target: int, budget: int, fast: bool) -> None:
    """Only scientific children create data; the root forwards the finalizer's report."""
    initial_node = Int(initial)
    outputs, root = run_get_node(
        workflow, initial=initial_node, target=Int(target), max_steps=Int(budget), fast=Bool(fast)
    )
    stride = 2 if fast else 1
    distance = abs(target - initial)
    attempts = min(budget, (distance + stride - 1) // stride)
    travelled = min(distance, attempts * stride)
    value = initial + (travelled if target >= initial else -travelled)
    converged = value == target
    mode = 'square' if converged else 'unfinished'
    assert root.is_finished_ok
    assert set(outputs) == {'result'}
    assert outputs['result'].get_dict() == {
        'value': value,
        'target': target,
        'attempts': attempts,
        'converged': converged,
        'mode': mode,
        'score': value**2 if converged else -1,
    }

    trials = sorted(
        (child for child in root.called if child.process_class is TrialWorkChain), key=lambda child: child.pk
    )
    finalizers = [child for child in root.called if child.process_class is FinalizeWorkChain]
    assert len(trials) == attempts
    assert len(finalizers) == 1
    assert len(root.called) == attempts + 1
    previous = initial_node
    for child in trials:
        assert child.is_finished_ok
        assert child.caller.uuid == root.uuid
        assert child.inputs.value.uuid == previous.uuid
        assert child.inputs.target.value == target
        assert child.inputs.stride.value == stride
        next_value = child.outputs.value
        assert min(initial, target) <= next_value.value <= max(initial, target)
        assert abs(next_value.value - target) < abs(previous.value - target)
        assert abs(next_value.value - previous.value) <= stride
        assert next_value.creator.caller.uuid == child.uuid
        previous = next_value

    finalizer = finalizers[0]
    assert finalizer.is_finished_ok
    assert finalizer.inputs.value.uuid == previous.uuid
    assert finalizer.inputs.target.value == target
    assert finalizer.inputs.attempts.value == attempts
    assert finalizer.inputs.mode.value == mode
    result = outputs['result']
    assert result.uuid == finalizer.outputs.result.uuid
    assert result.creator.caller.uuid == finalizer.uuid
    assert result.creator.process_label == 'summarize'
    assert root.base.links.get_outgoing(link_type=LinkType.RETURN).one().node.uuid == result.uuid
    assert root.base.links.get_outgoing(link_type=LinkType.CREATE).all() == []
