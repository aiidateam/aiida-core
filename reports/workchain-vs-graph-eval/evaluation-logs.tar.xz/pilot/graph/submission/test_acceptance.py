###########################################################################
# Copyright (c), The AiiDA team. All rights reserved.                     #
# This file is part of the AiiDA code.                                    #
#                                                                         #
# The code is hosted on GitHub at https://github.com/aiidateam/aiida-core #
# For further information on the license, see the LICENSE.txt file        #
# For further information please visit http://www.aiida.net               #
###########################################################################
"""Identical evaluator-owned behavioral/provenance checks for both arms."""

import pytest

from aiida.common.links import LinkType
from aiida.engine import run_get_node
from aiida.orm import Bool, Dict, Int
from tests.engine.processes.workflow_eval.solution import workflow

pytestmark = [pytest.mark.presto, pytest.mark.usefixtures('aiida_profile_clean')]


@pytest.mark.parametrize('initial,target,budget,fast', [
    (0, 5, 8, False), (0, 5, 8, True), (0, 5, 2, False), (0, 5, 2, True),
    (3, 3, 0, False), (3, 3, 8, True), (0, 5, 0, True),
    (5, -2, 7, False), (5, -2, 4, True), (-7, -1, 3, True),
    (-7, -1, 2, True), (-3, -8, 3, True), (2, 0, 1, True),
])
def test_contract(initial, target, budget, fast):
    """Check exact loop budget, branch selection, child inputs, and node identity."""
    outputs, root = run_get_node(
        workflow, initial=Int(initial), target=Int(target), max_steps=Int(budget), fast=Bool(fast)
    )
    stride = 2 if fast else 1
    attempts = min(budget, (abs(target - initial) + stride - 1) // stride)
    distance = min(abs(target - initial), attempts * stride)
    value = initial + (distance if target > initial else -distance)
    converged = value == target
    mode = 'square' if converged else 'unfinished'
    assert root.is_finished_ok
    assert isinstance(outputs['result'], Dict)
    assert outputs['result'].get_dict() == {
        'value': value, 'target': target, 'attempts': attempts,
        'converged': converged, 'mode': mode, 'score': value**2 if converged else -1,
    }
    trials = sorted(
        (child for child in root.called if child.process_label == 'TrialWorkChain'),
        key=lambda child: child.ctime,
    )
    finalizers = [child for child in root.called if child.process_label == 'FinalizeWorkChain']
    assert len(trials) == attempts
    assert len(finalizers) == 1
    assert len(root.called) == attempts + 1
    assert all(child.is_finished_ok for child in root.called)
    root_inputs = root.inputs.get('graph_inputs', root.inputs)
    previous = root_inputs.initial
    for trial in trials:
        assert trial.inputs.value.uuid == previous.uuid
        assert trial.inputs.target.value == target
        assert trial.inputs.stride.value == stride
        assert len(trial.called) == 1
        assert trial.outputs.value.base.links.get_incoming(link_type=LinkType.CREATE).one().node == trial.called[0]
        previous = trial.outputs.value
    finalizer = finalizers[0]
    assert finalizer.inputs.value.uuid == previous.uuid
    assert finalizer.inputs.attempts.value == attempts
    assert finalizer.inputs.mode.value == mode
    assert finalizer.outputs.result.uuid == outputs['result'].uuid
    assert root.base.links.get_outgoing(link_type=LinkType.CREATE).all() == []
    assert outputs['result'].base.links.get_incoming(link_type=LinkType.CREATE).one().node in finalizer.called
